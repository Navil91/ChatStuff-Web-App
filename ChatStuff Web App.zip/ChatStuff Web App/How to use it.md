# ChatStuff Web App
Realtime messenger web client with Websockets using Socket.io, Node.js and Express on the backend and with Vanilla JS on the frontend.

# Deployment
open source code editor
open the ChatStuff Web App folder
open terminal then...
npm install
npm run dev

open web broser
Go to localhost:3000

2nd user open another tab 
Go to localhost:3000


Enjoy the web app. 

# Created by Navil Hassan
